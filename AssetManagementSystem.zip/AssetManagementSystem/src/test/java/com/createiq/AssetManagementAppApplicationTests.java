package com.createiq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
