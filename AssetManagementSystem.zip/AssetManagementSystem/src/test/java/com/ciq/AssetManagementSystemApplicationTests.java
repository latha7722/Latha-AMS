package com.ciq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
