package com.createiq.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.createiq.entity.Lab;

public interface LabRepository extends JpaRepository<Lab, Long>{

}
